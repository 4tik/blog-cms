@extends('layouts.app')

@section('content')
    <h1>welcome to posts index</h1>
@endsection
