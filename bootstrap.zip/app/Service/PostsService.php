<?php

namespace App\Service;

use App\Http\Requests\post;
use App\Models\Posts;
use Illuminate\Http\Request;

interface PostsService{
    public function storePost(post $post):void;
}
