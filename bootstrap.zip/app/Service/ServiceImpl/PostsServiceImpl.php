<?php

namespace App\Service\ServiceImpl;

use App\Http\Requests\post;
use App\Models\Posts;
use App\Service\PostsService;
use Illuminate\Http\Request;

class PostsServiceImpl implements PostsService{
    public function storePost(post $post):void{
        print_r($post);
        $post = new Posts();
        $post->title =  'shdgf';
        $post->description =  'this is ok';
        $post->category =  'this';
        $post->save();
    }
}
