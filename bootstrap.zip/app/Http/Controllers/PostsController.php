<?php

namespace App\Http\Controllers;

use App\Http\Requests\post;
use App\Models\Posts;
use App\Service\PostsService;
use Illuminate\Http\Request;

class PostsController extends Controller
{
    private $postService;

    public function __construct(PostsService $postService) {
        $this->postService = $postService;
    }

    public function index(){
        $posts = Posts::all();
        return view('posts.index', compact('posts'));
    }

    public function create(){
        return view('posts.create');
    }

    public function store(post $post){
        //dd($request);
//        Posts::create([
//            'title' => request('title'),
//            'description' => request('description'),
//            'category' => 'this',
//            'user_id' => auth()->id()
//        ]);
        //$this->post->storePost($request);
        //dd($request);
        //$postsService->storePost($request);
        //dd($post);
        //$name=$post->only(['title', 'description']);

        $this->postService->storePost($post);

        return view('posts.index');
    }
}
