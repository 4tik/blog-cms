<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="container">

                    <div class="comment-form-wrap pt-5">
                        <h3 class="mb-5">Post Create</h3>
                        <form method="POST" action="<?php echo e(route('posts.store')); ?>" class="p-5 bg-light">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Title *</label>
                                <input type="text" name="title" class="form-control" value="<?php echo e(old('title', optional($post ?? null)->title)); ?>">
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <input id="description" name="description" type="text" class="form-control value="<?php echo e(old('description')); ?>">
                            </div>

                            <br/>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Submit')); ?>

                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SyntaxError\laravel-project\blog-cms\resources\views/posts/create.blade.php ENDPATH**/ ?>