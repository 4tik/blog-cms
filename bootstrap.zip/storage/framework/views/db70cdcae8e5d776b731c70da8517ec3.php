<?php $__env->startSection('content'); ?>
    <h1>welcome to posts index</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SyntaxError\laravel-project\blog-cms\resources\views/posts/index.blade.php ENDPATH**/ ?>