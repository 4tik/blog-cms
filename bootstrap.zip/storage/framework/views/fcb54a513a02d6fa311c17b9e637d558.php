<?php echo e($slot); ?>

<?php /**PATH D:\SyntaxError\laravel-project\blog-cms\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>